﻿//Suma esquinas matriz
using System;

class Program
{
    static void Main()
    {
        // Crear una matriz aleatoria 3x3
        int[,] matriz3x3 = GenerarMatrizAleatoria(3, 3);

        // Crear una matriz aleatoria 4x4
        int[,] matriz4x4 = GenerarMatrizAleatoria(4, 4);

        // Mostrar las matrices generadas
        Console.WriteLine("Matriz 3x3:");
        MostrarMatriz(matriz3x3);

        Console.WriteLine("\nMatriz 4x4:");
        MostrarMatriz(matriz4x4);

        // Suma de las esquinas
        int sumaEsquinas3x3 = SumarEsquinas(matriz3x3);
        int sumaEsquinas4x4 = SumarEsquinas(matriz4x4);

        // Mostrar resultados
        Console.WriteLine("\nSuma de las esquinas en matriz 3x3: " + sumaEsquinas3x3);
        Console.WriteLine("Suma de las esquinas en matriz 4x4: " + sumaEsquinas4x4);
    }

    static int[,] GenerarMatrizAleatoria(int filas, int columnas)
    {
        Random random = new Random();
        int[,] matriz = new int[filas, columnas];

        for (int i = 0; i < filas; i++)
        {
            for (int j = 0; j < columnas; j++)
            {
                matriz[i, j] = random.Next(1, 100); // Números aleatorios entre 1 y 100
            }
        }

        return matriz;
    }

    static void MostrarMatriz(int[,] matriz)
    {
        int filas = matriz.GetLength(0);
        int columnas = matriz.GetLength(1);

        for (int i = 0; i < filas; i++)
        {
            for (int j = 0; j < columnas; j++)
            {
                Console.Write(matriz[i, j] + "\t");
            }
            Console.WriteLine();
        }
    }

    static int SumarEsquinas(int[,] matriz)
    {
        int filas = matriz.GetLength(0);
        int columnas = matriz.GetLength(1);

        if (filas != columnas || filas < 3)
        {
            Console.WriteLine("La matriz no es válida para la operación.");
            return 0;
        }

        int suma = 0;

        for (int i = 0; i < filas; i++)
        {
            // Sumar las esquinas
            if (i == 0 || i == filas - 1)
            {
                for (int j = 0; j < columnas; j++)
                {
                    if (j == 0 || j == columnas - 1)
                    {
                        suma += matriz[i, j];
                    }
                }
            }
        }

        return suma;
    }
}
